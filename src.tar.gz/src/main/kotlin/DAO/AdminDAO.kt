package com.flightbooking

import java.sql.Connection

/**
 * DAO object used for admin database queries.
 *
 * This object contains functions that help fetch data for the admin side of
 * the flight booking system. It is used for the dashboard
 * information, such as total users, booking statistics, recent bookings,
 * cancellations, upcoming flights, and busiest routes.
 *
 * Each function connects to the database, runs a query, and returns the
 * results in a simple format that can be used by the rest of the program.
 *
 * If a query fails, the functions usually return a default value like `0`
 * or an empty list instead of crashing the program.
 */
object AdminDAO {
    /**
    * Returns the total number of users stored in the database.
    *
    * This function executes a SQL `COUNT(*)` query on the `users` table and
    * returns the result as an `Int`.
    *
    * If the query fails or any database error occurs, the function returns `0`.
    *
    * @return the total number of users in the `users` table, or `0` if the query fails
    */
    fun getTotalUsers(): Int {
        val sql = "SELECT COUNT(*) FROM users"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.executeQuery().use { rs ->
                        if (rs.next()) rs.getInt(1) else 0
                    }
                }
            }
        } catch (e: Exception) {
            0
        }
    }


    /**
    * Retrieves all bookings grouped by booking date.
    *
    * This function queries the `bookings` table and groups records by the date
    * portion of `booking_date`. For each date, it returns the total number of
    * bookings and the total revenue generated.
    *
    * Each result map contains:
    * - `"date"`: the booking date as a `String`
    * - `"count"`: the number of bookings on that date
    * - `"revenue"`: the total revenue for that date as a `Double`
    *
    * The results are ordered by date in ascending order.
    *
    * If an error occurs while accessing the database, an empty list is returned.
    *
    * @return a list of maps containing the date, booking count, and total revenue
    * for each booking date, or an empty list if the query fails
    */
    fun getAllBookingsGroupedByDate(filterSeason: String? = null): List<Map<String, Any>> {
        var sql: String
        if (!filterSeason.isNullOrEmpty()) {
            sql = """
                SELECT DATE(b.booking_date) as booking_date,
                    COUNT(*) as booking_count,
                    SUM(b.total_price) as total_revenue
                FROM bookings b
                JOIN booking_flights bf ON b.booking_id = bf.booking_id
                JOIN flights f ON bf.flight_id = f.flight_id
                JOIN routes r ON f.route_id = r.route_id
                WHERE r.season = ?
                GROUP BY DATE(b.booking_date)
                ORDER BY booking_date DESC
            """
        } else {
            sql = """
                SELECT DATE(b.booking_date) as booking_date,
                    COUNT(*) as booking_count,
                    SUM(b.total_price) as total_revenue
                FROM bookings b
                GROUP BY DATE(b.booking_date)
                ORDER BY booking_date DESC
            """
        }
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    if (!filterSeason.isNullOrEmpty()) {
                        stmt.setString(1, filterSeason)
                    }
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            results.add(mapOf(
                                "date"    to (rs.getString("booking_date") ?: ""),
                                "count"   to rs.getInt("booking_count"),
                                "revenue" to rs.getDouble("total_revenue"),
                            ))
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }


    /**
    * Retrieves the number of bookings for each booking status.
    *
    * This function queries the `bookings` table, groups records by `status`,
    * and counts how many bookings exist for each status value.
    *
    * Each result map contains:
    * - `"status"`: the booking status as a `String`
    * - `"count"`: the number of bookings with that status as an `Int`
    *
    * If an error occurs while querying the database, an empty list is returned.
    *
    * @return a list of maps containing each booking status and its corresponding
    * count, or an empty list if the query fails
    */
    fun getBookingStatusCounts(): List<Map<String, Any>> {
        val sql = """
            SELECT status, COUNT(*) as count
            FROM bookings
            GROUP BY status
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            results.add(
                                mapOf(
                                    "status" to rs.getString("status"),
                                    "count" to rs.getInt("count"),
                                ),
                            )
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }


    /**
    * Retrieves the most recent bookings from the database.
    *
    * This function queries the `bookings` table, orders bookings by
    * `booking_date` in descending order, and returns up to the specified
    * number of results.
    *
    * Each result map contains:
    * - `"bookingId"`: the booking ID as an `Int`
    * - `"bookingDate"`: the booking date as a `String`
    * - `"totalPrice"`: the total booking price as a `Double`
    * - `"status"`: the booking status as a `String`
    * - `"contactEmail"`: the contact email associated with the booking
    *
    * If an error occurs while querying the database, an empty list is returned.
    *
    * @param limit the maximum number of recent bookings to return; defaults to 20
    * @return a list of maps containing recent booking details, or an empty list
    * if the query fails
    */
    fun getRecentBookings(limit: Int = 20): List<Map<String, Any>> {
        val sql = """
            SELECT b.booking_id, b.booking_date, b.total_price, b.status, b.contact_email
            FROM bookings b
            ORDER BY b.booking_date DESC
            LIMIT ?
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, limit)
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            results.add(
                                mapOf(
                                    "bookingId" to rs.getInt("booking_id"),
                                    "bookingDate" to (rs.getString("booking_date") ?: ""),
                                    "totalPrice" to rs.getDouble("total_price"),
                                    "status" to rs.getString("status"),
                                    "contactEmail" to (rs.getString("contact_email") ?: ""),
                                ),
                            )
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }


    /**
    * Retrieves the most recent cancelled bookings from the database.
    *
    * This function queries the `bookings` table for records with a status of
    * `"cancelled"`, orders them by `booking_date` in descending order, and
    * returns up to the specified number of results.
    *
    * Each result map contains:
    * - `"bookingId"`: the booking ID as an `Int`
    * - `"bookingDate"`: the booking date as a `String`
    * - `"totalPrice"`: the total price of the booking as a `Double`
    * - `"contactEmail"`: the contact email associated with the booking
    *
    * If an error occurs while querying the database, an empty list is returned.
    *
    * @param limit the maximum number of recent cancelled bookings to return; defaults to 20
    * @return a list of maps containing recent cancelled booking details, or an empty list
    * if the query fails
    */
    fun getRecentCancellations(limit: Int = 20): List<Map<String, Any>> {
        val sql = """
            SELECT b.booking_id, b.booking_date, b.total_price, b.contact_email
            FROM bookings b
            WHERE b.status = 'cancelled'
            ORDER BY b.booking_date DESC
            LIMIT ?
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, limit)
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            results.add(
                                mapOf(
                                    "bookingId" to rs.getInt("booking_id"),
                                    "bookingDate" to (rs.getString("booking_date") ?: ""),
                                    "totalPrice" to rs.getDouble("total_price"),
                                    "contactEmail" to (rs.getString("contact_email") ?: ""),
                                ),
                            )
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }


    /**
    * Gets a list of upcoming flights from the database.
    *
    * This function looks for flights whose `flight_date` is today or later.
    * It joins the `flights`, `routes`, and `airports` tables so it can return extra information like the flight number, departure time, and the
    * departure and arrival cities.
    *
    * The flights are sorted by flight date first, and then by planned departure time. The number of results returned is limited by the `limit`
    * parameter.
    *
    * Each map in the returned list contains:
    * - `"flightId"`: the flight ID
    * - `"flightDate"`: the date of the flight
    * - `"status"`: the current flight status
    * - `"flightNumber"`: the flight number
    * - `"departureTime"`: the planned departure time
    * - `"departureCity"`: the city the flight leaves from
    * - `"arrivalCity"`: the city the flight arrives at
    * - `"price"`: the price of the flight
    *
    * If something goes wrong with the database query, the function returns an
    * empty list.
    *
    * @param limit the maximum number of upcoming flights to return, default is 20
    * @return a list of maps containing upcoming flight details, or an empty list if the query fails
    */
    fun getUpcomingFlights(limit: Int = 20): List<Map<String, Any>> {
        val sql = """
            SELECT f.flight_id, f.flight_date, f.status, f.price,
                   r.flight_number, r.planned_departure,
                   dep.name as departure_city, arr.name as arrival_city
            FROM flights f
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            WHERE f.flight_date >= DATE('now')
            ORDER BY f.flight_date ASC, r.planned_departure ASC
            LIMIT ?
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, limit)
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            results.add(
                                mapOf(
                                    "flightId" to rs.getInt("flight_id"),
                                    "flightDate" to (rs.getString("flight_date") ?: ""),
                                    "status" to rs.getString("status"),
                                    "flightNumber" to rs.getString("flight_number"),
                                    "departureTime" to (rs.getString("planned_departure") ?: ""),
                                    "departureCity" to rs.getString("departure_city"),
                                    "arrivalCity" to rs.getString("arrival_city"),
                                    "price" to rs.getDouble("price"),
                                ),
                            )
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }


    /**
    * Gets the busiest routes based on how many bookings they have.
    *
    * This function checks the booking and flight tables, joins them with the
    * route and airport tables, and works out which routes have the highest number of bookings.
    *
    * The results are ordered from most booked to least booked. The `limit`parameter controls how many routes are returned.
    *
    * Each map in the list contains:
    * - `"departureCity"`: the city the flight leaves from
    * - `"arrivalCity"`: the city the flight goes to
    * - `"flightNumber"`: the flight number for the route
    * - `"bookingCount"`: how many bookings that route has
    *
    * If there is a problem with the database, the function returns an empty list.
    *
    * @param limit the max number of routes to return, default is 10
    * @return a list of maps with the busiest route details, or an empty list if the query fails
    */
    fun getBusiestRoutes(limit: Int = 10, startDate: String? = null, endDate: String? = null, filterSeason: String? = null): List<Map<String, Any>> {
        var sql = """
            SELECT dep.name as departure_city, arr.name as arrival_city,
                   r.flight_number, COUNT(*) as booking_count
            FROM booking_flights bf
            JOIN flights f ON bf.flight_id = f.flight_id
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            WHERE 1=1
        """
        if (!filterSeason.isNullOrEmpty()) {
            sql += " AND r.season = ?"
        }
        if (!startDate.isNullOrEmpty()) {
            sql += " AND f.flight_date >= ?"
        }
        if (!endDate.isNullOrEmpty()) {
            sql += " AND f.flight_date <= ?"
        }
        sql += """
            GROUP BY r.route_id
            HAVING booking_count > 0
            ORDER BY booking_count DESC
            LIMIT ?
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    var paramIndex = 1
                    if (!filterSeason.isNullOrEmpty()) {
                        stmt.setString(paramIndex++, filterSeason)
                    }
                    if (!startDate.isNullOrEmpty()) {
                        stmt.setString(paramIndex++, startDate)
                    }
                    if (!endDate.isNullOrEmpty()) {
                        stmt.setString(paramIndex++, endDate)
                    }
                    stmt.setInt(paramIndex, limit)
                    stmt.setInt(paramIndex, limit)
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            results.add(
                                mapOf(
                                    "departureCity" to rs.getString("departure_city"),
                                    "arrivalCity" to rs.getString("arrival_city"),
                                    "flightNumber" to rs.getString("flight_number"),
                                    "bookingCount" to rs.getInt("booking_count"),
                                ),
                            )
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun trackReservations(filterDate: String? = null, filterUsername: String? = null, filterStatus: String? = null): List<Map<String, Any>> {
        
        var sql = """
            SELECT b.booking_id,
                   b.booking_date,
                   b.total_price,
                   b.status,
                   b.contact_email,
                   u.first_name,
                   u.last_name,
                   (SELECT GROUP_CONCAT(p.full_name)
                    FROM booking_passengers p
                    WHERE p.booking_id = b.booking_id) AS passenger_names
            FROM bookings b
            JOIN users u ON b.user_id = u.user_id 
            WHERE 1=1
        """

        if (filterDate != null && filterDate.isNotEmpty()) {
            sql += " AND strftime('%Y-%m-%d', b.booking_date) = ?"
        }

        if (filterUsername != null && filterUsername.isNotEmpty()) {
            sql += """ AND(
                u.first_name LIKE ?
                OR u.last_name LIKE ?
                OR EXISTS (SELECT 1 FROM booking_passengers bp WHERE bp.booking_id = b.booking_id AND bp.full_name LIKE ?)
            )"""
        }

        if (filterStatus != null && filterStatus.isNotEmpty()) {
            sql += " AND b.status = ?"
        }

        sql += " ORDER BY b.booking_date DESC"

        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    var paramIndex = 1

                    if (filterDate != null && filterDate.isNotEmpty()) {
                        stmt.setString(paramIndex++, filterDate)
                    }

                    if (filterUsername != null && filterUsername.isNotEmpty()) {
                        val searchPattern = "%$filterUsername%"
                        stmt.setString(paramIndex++, searchPattern) 
                        stmt.setString(paramIndex++, searchPattern) 
                    }

                    if (filterStatus != null && filterStatus.isNotEmpty()) {
                        stmt.setString(paramIndex++, filterStatus)
                    }

                    println("Debug: SQL query is $sql")
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            val row = mutableMapOf<String, Any>()
                            
                            row["bookingId"] = rs.getInt("booking_id")
                            row["bookingDate"] = rs.getString("booking_date") ?: ""
                            row["totalPrice"] = rs.getDouble("total_price")
                            row["status"] = rs.getString("status") ?: ""
                            row["contactEmail"] = rs.getString("contact_email") ?: ""
                            row["bookedBy"] = (rs.getString("first_name") ?: "") + " " + (rs.getString("last_name") ?: "")
                            row["passengers"] = rs.getString("passenger_names") ?: "N/A"

                            results.add(row)
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            println("Search Error:")
            e.printStackTrace()
            emptyList()
        }
    }

    fun trackFlights(filterDate: String? = null, filterNumber: String? = null): List<Map<String, Any>> {
        // Default to today if no date is provided — avoids loading all 10000+ flights at once
        val effectiveDate = if (filterDate.isNullOrEmpty()) {
            java.time.LocalDate.now().toString()
        } else {
            filterDate
        }

        var sql = """
            SELECT f.flight_id, 
                f.flight_date, 
                f.status, 
                r.flight_number, 
                f.departure_localtime,
                f.arrival_localtime,
                f.overnight,
                dep.name AS dep_name,
                arr.name AS arr_name
            FROM flights f
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            WHERE f.flight_date = ?
        """

        if (!filterNumber.isNullOrEmpty()) {
            sql += " AND r.flight_number LIKE ?"
        }

        sql += " ORDER BY f.departure_localtime ASC"

        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    var paramIndex = 1
                    stmt.setString(paramIndex++, effectiveDate)
                    if (!filterNumber.isNullOrEmpty()) {
                        stmt.setString(paramIndex++, "%$filterNumber%")
                    }

                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            val row = mutableMapOf<String, Any>()
                            row["flightId"] = rs.getInt("flight_id")
                            row["flightDate"] = rs.getString("flight_date") ?: ""
                            row["status"] = rs.getString("status") ?: ""
                            row["flightNumber"] = rs.getString("flight_number") ?: ""
                            row["originCity"] = rs.getString("dep_name") ?: ""
                            row["destCity"] = rs.getString("arr_name") ?: ""
                            row["depTime"] = rs.getString("departure_localtime") ?: ""
                            row["arrTime"] = rs.getString("arrival_localtime") ?: ""
                            row["overnight"] = rs.getInt("overnight") == 1
                            results.add(row)
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            println("TrackFlights Error:")
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * Returns the previous and next date relative to the given date string (yyyy-MM-dd).
     * Used for day-by-day flight navigation in the admin dashboard.
     */
    fun getAdjacentFlightDates(currentDate: String): Map<String, String> {
        val date = try {
            java.time.LocalDate.parse(currentDate)
        } catch (e: Exception) {
            java.time.LocalDate.now()
        }
        return mapOf(
            "prevDate" to date.minusDays(1).toString(),
            "nextDate" to date.plusDays(1).toString()
        )
    }

    fun updateFlightStatus(flightId: Int, newStatus: String): Boolean {
        val allowedStatuses = setOf("Scheduled", "Delayed", "Cancelled", "Departed", "Arrived")
        if (newStatus !in allowedStatuses) return false

        val sql = "UPDATE flights SET status = ? WHERE flight_id = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, newStatus)
                    stmt.setInt(2, flightId)
                    stmt.executeUpdate() > 0
                }
            }
        } catch (e: Exception) {
            println("UpdateFlightStatus Error:")
            e.printStackTrace()
            false
        }
    }

    fun getFlightStatusNotification(flightId: Int, newStatus: String): FlightStatusNotification? {
        val notifiableStatuses: Set<String> = setOf("Delayed", "Cancelled")
        if (newStatus !in notifiableStatuses) return null
        val sql = """
            SELECT f.flight_id,
                f.status,
                f.flight_date,
                r.flight_number,
                dep.city AS departure_city,
                arr.city AS arrival_city,
                b.contact_email,
                u.email AS user_email
            FROM flights f
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            LEFT JOIN booking_flights bf ON f.flight_id = bf.flight_id
            LEFT JOIN bookings b ON bf.booking_id = b.booking_id AND b.status != 'cancelled'
            LEFT JOIN users u ON b.user_id = u.user_id
            WHERE f.flight_id = ?
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, flightId)
                    stmt.executeQuery().use { result ->
                        val recipientEmails: MutableList<String> = mutableListOf()
                        var flightNumber: String = ""
                        var flightDate: String = ""
                        var originCity: String = ""
                        var destinationCity: String = ""
                        var oldStatus: String = ""
                        var hasFlight: Boolean = false
                        while (result.next()) {
                            hasFlight = true
                            flightNumber = result.getString("flight_number") ?: flightNumber
                            flightDate = result.getString("flight_date") ?: flightDate
                            originCity = result.getString("departure_city") ?: originCity
                            destinationCity = result.getString("arrival_city") ?: destinationCity
                            oldStatus = result.getString("status") ?: oldStatus
                            recipientEmails.add(result.getString("contact_email") ?: "")
                            recipientEmails.add(result.getString("user_email") ?: "")
                        }
                        if (!hasFlight || oldStatus != "Scheduled") return@use null
                        FlightStatusNotification(
                            flightId = flightId,
                            flightNumber = flightNumber,
                            flightDate = flightDate,
                            originCity = originCity,
                            destinationCity = destinationCity,
                            oldStatus = oldStatus,
                            newStatus = newStatus,
                            recipientEmails = recipientEmails,
                        )
                    }
                }
            }
        } catch (e: Exception) {
            null
        }
    }
    
    fun getBookingsPerFlight(limit: Int = 20, filterDate: String? = null, filterSeason: String? = null): List<Map<String, Any>> {
        var sql = """
            SELECT r.flight_number,
                f.flight_date,
                dep.name AS origin,
                arr.name AS dest,
                COUNT(bf.booking_id) AS booking_count
            FROM flights f
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            LEFT JOIN booking_flights bf ON f.flight_id = bf.flight_id
            WHERE 1=1
        """
        if (!filterDate.isNullOrEmpty()) {
            sql += " AND f.flight_date = ?"
        }
        if (!filterSeason.isNullOrEmpty()) {
            sql += " AND r.season = ?"
        }
        sql += """
            GROUP BY f.flight_id, r.flight_number, f.flight_date, dep.name, arr.name
            ORDER BY f.flight_date DESC, booking_count DESC
            LIMIT ?
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    var paramIndex = 1
                    if (!filterDate.isNullOrEmpty()) {
                        stmt.setString(paramIndex++, filterDate)
                    }
                    if (!filterSeason.isNullOrEmpty()) {
                        stmt.setString(paramIndex++, filterSeason)
                    }
                    stmt.setInt(paramIndex, limit)
                    stmt.executeQuery().use { rs ->
                        val results = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            results.add(mapOf(
                                "flightNumber" to (rs.getString("flight_number") ?: ""),
                                "flightDate"   to (rs.getString("flight_date") ?: ""),
                                "origin"       to (rs.getString("origin") ?: ""),
                                "dest"         to (rs.getString("dest") ?: ""),
                                "bookingCount" to rs.getInt("booking_count")
                            ))
                        }
                        results
                    }
                }
            }
        } catch (e: Exception) {
            println("GetBookingsPerFlight Error:")
            e.printStackTrace()
            emptyList()
        }
    }

fun getPendingChangeRequests(): List<Map<String, Any>> {
        val sql = """
            SELECT 
                change_requests.rowid AS request_id,
                change_requests.user_id, 
                change_requests.change_to, 
                change_requests.change_type, 
                users.email AS username 
            FROM change_requests 
            LEFT JOIN users ON change_requests.user_id = users.user_id 
            WHERE change_requests.status = 'pending'
        """
    
        val requests = mutableListOf<Map<String, Any>>()
    
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    val rs = stmt.executeQuery()
                    while (rs.next()) {
                        try {
                            val row = mutableMapOf<String, Any>()
                            row["requestId"] = rs.getLong("request_id")
                            row["userId"] = rs.getInt("user_id")
                            row["changeTo"] = rs.getString("change_to") ?: ""
                            row["type"] = rs.getString("change_type") ?: ""
                            row["username"] = rs.getString("username") ?: "Unknown Email"
                        
                            requests.add(row)
                        } catch (rowError: Exception) {
                            println("DEBUG: Row parsing error: ${rowError.message}")
                        }
                    }
                }
            }
            println("DEBUG: Successfully fetched ${requests.size} requests from DB")
            requests
        } catch (e: Exception) {
            println("DEBUG: SQL Error: ${e.message}")
            e.printStackTrace()
            emptyList()
        }
    }

    fun updateRequestStatus(userId: Int, newStatus: String): Boolean {
        val sql = "UPDATE change_requests SET status = ? WHERE user_id = ? AND status = 'pending'"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, newStatus)
                    stmt.setInt(2, userId)
                    stmt.executeUpdate() > 0
                }
            }
        } catch (e: Exception) { false }
    }

    fun approveChangeRequest(userId: Int): Boolean {
        return try {
            Database.getConnection().use { conn ->
                val requestId: Long = getFirstPendingRequestId(conn, userId) ?: return false
                approveChangeRequest(conn, requestId, userId)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun approveChangeRequest(requestId: Long, userId: Int): Boolean {
        return try {
            Database.getConnection().use { conn ->
                approveChangeRequest(conn, requestId, userId)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    internal fun approveChangeRequest(conn: Connection, requestId: Long, userId: Int): Boolean {
        val pendingData: String = getPendingDataByRequestId(conn, requestId, userId) ?: return false
        val parts = pendingData.trim().split(Regex("\\s+"))
        if (parts.size < 2) return false
        val newFullName: String = parts[0]
        val newIdNumber: String = parts[1]
        val sqlUpdatePassenger = """
            UPDATE booking_passengers 
            SET full_name = ?, id_number = ? 
            WHERE booking_id IN (SELECT booking_id FROM bookings WHERE user_id = ?)
        """
        val sqlUpdateStatus = "UPDATE change_requests SET status = 'accepted' WHERE rowid = ? AND user_id = ? AND status = 'pending'"
        return try {
            val originalAutoCommit: Boolean = conn.autoCommit
            conn.autoCommit = false
            try {
                conn.prepareStatement(sqlUpdatePassenger).use { stmt ->
                    stmt.setString(1, newFullName)
                    stmt.setString(2, newIdNumber)
                    stmt.setInt(3, userId)
                    stmt.executeUpdate()
                }
                val updatedRequestCount: Int = conn.prepareStatement(sqlUpdateStatus).use { stmt ->
                    stmt.setLong(1, requestId)
                    stmt.setInt(2, userId)
                    stmt.executeUpdate()
                }
                conn.commit()
                updatedRequestCount > 0
            } catch (e: Exception) {
                conn.rollback()
                throw e
            } finally {
                conn.autoCommit = originalAutoCommit
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    
    private fun getFirstPendingRequestId(conn: Connection, userId: Int): Long? {
        val sql = "SELECT rowid FROM change_requests WHERE user_id = ? AND status = 'pending' ORDER BY rowid LIMIT 1"
        return try {
            conn.prepareStatement(sql).use { stmt ->
                stmt.setInt(1, userId)
                val rs = stmt.executeQuery()
                if (rs.next()) rs.getLong("rowid") else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun getPendingDataByRequestId(conn: Connection, requestId: Long, userId: Int): String? {
        val sql = "SELECT change_to FROM change_requests WHERE rowid = ? AND user_id = ? AND status = 'pending'"
        return try {
            conn.prepareStatement(sql).use { stmt ->
                stmt.setLong(1, requestId)
                stmt.setInt(2, userId)
                val rs = stmt.executeQuery()
                if (rs.next()) rs.getString("change_to") else null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun rejectChangeRequest(userId: Int): Boolean {
        return try {
            Database.getConnection().use { conn ->
                val requestId: Long = getFirstPendingRequestId(conn, userId) ?: return false
                rejectChangeRequest(conn, requestId, userId)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun rejectChangeRequest(requestId: Long, userId: Int): Boolean {
        return try {
            Database.getConnection().use { conn ->
                rejectChangeRequest(conn, requestId, userId)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    internal fun rejectChangeRequest(conn: Connection, requestId: Long, userId: Int): Boolean {
        val sql = "UPDATE change_requests SET status = 'rejected' WHERE rowid = ? AND user_id = ? AND status = 'pending'"
        return try {
            conn.prepareStatement(sql).use { stmt ->
                stmt.setLong(1, requestId)
                stmt.setInt(2, userId)
                stmt.executeUpdate() > 0
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

}