package com.flightbooking
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime


object UserDAO{

    fun getUserDetails(userId: Int): User? {
        val sql = "SELECT first_name, last_name, email FROM users WHERE user_id = ?"
        return Database.getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setInt(1, userId)
                val rs = stmt.executeQuery()
                if (rs.next()){
                    User(
                        firstName = rs.getString("first_name"),
                        lastName = rs.getString("last_name"),
                        email = rs.getString("email"),
                        passwordHash = ""
                    )
                }else null

            }

        }
    }

    /**
    * Checks if an email is already in the users table.
    *
    * @param email the email to check
    * @return true if the email exists, otherwise false
    */
    fun emailExists(email: String): Boolean {
        val sql = "SELECT count(*) FROM users WHERE email = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, email)
                    stmt.executeQuery().use { result ->
                        if (result.next()) {
                            result.getInt(1) > 0
                        } else {
                            false
                        }
                    }
                }
            }
        } catch (e: Exception) {
            false
        }
    }


    /**
    * Registers a new user in the database.
    *
    * It first checks if the password is valid and if the email is already used.
    * If both checks pass, the password is hashed and the user is added.
    *
    * @param user the user object
    * @param inputFirstName the user's first name
    * @param inputMiddleName the user's middle name
    * @param inputLastName the user's last name
    * @param inputEmail the user's email
    * @param inputPassword the user's password
    * @return true if the user was added, otherwise false
    */
    fun register(user: User, inputFirstName: String, inputMiddleName: String, inputLastName: String, inputEmail: String, inputPassword: String): Boolean {
        if (!Security.isPasswordValid(inputPassword)) return false
        if (emailExists(inputEmail)) return false

        val hashedPassword = Security.hashPassword(inputPassword)
        val sql = "INSERT INTO users(first_name, middle_name, last_name, email, password_hash) VALUES(?,?,?,?,?)"

        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, inputFirstName)
                    stmt.setString(2, inputMiddleName)
                    stmt.setString(3, inputLastName)
                    stmt.setString(4, inputEmail)
                    stmt.setString(5, hashedPassword)
                    stmt.executeUpdate() > 0
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }




    /**
    * Simple result for a login attempt.
    *
    * It stores whether the login worked and whether the user is an admin.
    */
    data class LoginResult(val success: Boolean, val isAdmin: Boolean = false)


    /**
    * Checks if a user can log in.
    *
    * It looks up the email, gets the saved password hash, and compares it
    * with the password the user entered.
    *
    * @param inputEmail the email entered by the user
    * @param inputPassword the password entered by the user
    * @return a `LoginResult` showing if the login worked
    */
    fun loginUser(inputEmail: String, inputPassword: String): LoginResult {
        // Check admins table first — match by email or username
        val adminSql = "SELECT password_hash FROM admins WHERE email = ? OR username = ?"
        try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(adminSql).use { stmt ->
                    stmt.setString(1, inputEmail)
                    stmt.setString(2, inputEmail)
                    stmt.executeQuery().use { result ->
                        if (result.next()) {
                            val hash = result.getString("password_hash")
                            return if (Security.verifyPassword(inputPassword, hash)) {
                                LoginResult(success = true, isAdmin = true)
                            } else {
                                LoginResult(success = false)
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            return LoginResult(success = false)
        }

        // Fall back to regular users table
        val userSql = "SELECT password_hash FROM users WHERE email = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(userSql).use { stmt ->
                    stmt.setString(1, inputEmail)
                    stmt.executeQuery().use { result ->
                        if (result.next()) {
                            val hash = result.getString("password_hash")
                            if (Security.verifyPassword(inputPassword, hash)) {
                                LoginResult(success = true)
                            } else {
                                LoginResult(success = false)
                            }
                        } else {
                            LoginResult(success = false)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            LoginResult(success = false)
        }
    }


    /**
    * Starts the password reset process for a user.
    *
    * It checks if the email exists, makes a one-time code, and sends it by email.
    *
    * @param inputEmail the email for the password reset
    * @return true if the reset email was sent, otherwise false
    */
    fun resetPassword(inputEmail: String):Boolean{
        if(!emailExists(inputEmail)){
            return false
        }
        return try {
            // email found, generate OTC and send email
            val generatedCode = OTC.generateAndSave(inputEmail)

            EmailService.sendEmail(
                to = inputEmail,
                subject = "Your One-Time Code for Password Reset",
                body = "Your one-time code is: $generatedCode. It will expire in 5 minutes.",
            )
            true
        } catch (e: Exception) {
            false
        }
    }


    /**
    * Finishes resetting a user's password.
    *
    * It checks the one-time code, checks the new password, and then updates
    * the saved password in the database.
    *
    * @param inputEmail the user's email
    * @param inputOTC the one-time code
    * @param newPassword the new password
    * @return true if the password was updated, otherwise false
    */
    fun confirmResetPassword(inputEmail: String, inputOTC: String, newPassword: String):Boolean{
        // check if OTC is valid and expired
        if (!OTC.verify(inputEmail, inputOTC)) {
            return false
        }

        // if OTC is valid, check new password validation
        if (!Security.isPasswordValid(newPassword)) {
            return false
        }

        // if valid, hash the new password and update to database
        val hashedNewPassword = Security.hashPassword(newPassword)
        val sql = "UPDATE users SET password_hash = ? WHERE email = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, hashedNewPassword)
                    stmt.setString(2, inputEmail)

                    val rowsAffected = stmt.executeUpdate()

                    rowsAffected > 0
                }
            }
        } catch (e: Exception) {
            false
        }
    }

    /**
    * Gets the user ID for an email.
    *
    * @param username the user's email
    * @return the user ID, or -1 if it is not found
    */
    fun getUserID(username: String): Int {
        val sql = "SELECT user_id FROM users WHERE email = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, username)
                    stmt.executeQuery().use { result ->
                        if (result.next()) result.getInt("user_id") else -1
                    }
                }
            }
        } catch (e: Exception) {
            -1
        }
    }

    /**
    * Turns one database row into a map of flight info.
    *
    * It reads the flight details, works out the arrival time, and puts the
    * values into a map.
    *
    * @param result the current row from the query result
    * @return a map with flight details like times, cities, airports, terminals, and duration
    */
    private fun getFlightInfoFromRow(result: java.sql.ResultSet): Map<String, Any> {
        val durationMinutes = result.getInt("base_duration_minutes")

        val departureDate = LocalDate.parse(result.getString("flight_date"))
        val departureTime = LocalTime.parse(result.getString("planned_departure"))

        val departureTimezone = ZoneId.of(result.getString("departure_timezone") ?: "UTC")
        val arrivalTimezone = ZoneId.of(result.getString("arrival_timezone") ?: "UTC")

        // work out the arrival time by adding the duration and converting to the arrival timezone
        val departureDateTime = ZonedDateTime.of(departureDate, departureTime, departureTimezone)
        val arrivalDateTime = departureDateTime.plusMinutes(durationMinutes.toLong())
        val arrivalTime = arrivalDateTime.withZoneSameInstant(arrivalTimezone).toLocalTime()

        val flightInfo = mutableMapOf<String, Any>()
        flightInfo["flightNumber"] = result.getString("flight_number")
        flightInfo["departureCity"] = result.getString("departure_city")
        flightInfo["arrivalCity"] = result.getString("arrival_city")
        flightInfo["departureAirport"] = result.getString("departure_airport_name")
        flightInfo["arrivalAirport"] = result.getString("arrival_airport_name")
        flightInfo["departureTerminal"] = result.getString("departure_terminal") ?: ""
        flightInfo["arrivalTerminal"] = result.getString("arrival_terminal") ?: ""
        flightInfo["departureDate"] = departureDate.toString()
        flightInfo["departureTime"] = departureTime.toString()
        flightInfo["arrivalTime"] = arrivalTime.toString()
        flightInfo["duration"] = Utils.formatDuration(durationMinutes)
        return flightInfo
    }


    /**
    * Gets all non-cancelled bookings for a user.
    *
    * It also groups together any flights that belong to the same booking.
    *
    * @param userID the ID of the user
    * @return a list of booking maps, where each booking includes its flight details
    */
    fun getBookings(userID: Int): List<Map<String, Any>> {
        // get all bookings for the user, joining to get the flight and route info
        // a booking can have multiple flights so we group by booking_id at the end
        val sql = """
            SELECT
                b.booking_id, b.booking_date, b.total_price, b.status,
                f.flight_date,
                r.flight_number, r.departure_terminal, r.arrival_terminal,
                r.planned_departure, r.base_duration_minutes,
                dep.city as departure_city, arr.city as arrival_city,
                dep.name as departure_airport_name, arr.name as arrival_airport_name,
                dep.timezone as departure_timezone, arr.timezone as arrival_timezone,
                bf.flight_sequence
            FROM bookings b
            JOIN booking_flights bf ON b.booking_id = bf.booking_id
            JOIN flights f ON bf.flight_id = f.flight_id
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            WHERE b.user_id = ? AND b.status != 'cancelled'
            ORDER BY b.booking_id, bf.flight_sequence
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, userID)
                    stmt.executeQuery().use { result ->
                        // use a map so we can group flights under the same booking
                        val bookings = mutableListOf<MutableMap<String, Any>>()
                        val seenBookingIds = mutableMapOf<Int, MutableMap<String, Any>>()

                        while (result.next()) {
                            val bookingId = result.getInt("booking_id")

                            // if we haven't seen this booking before, create a new entry for it
                            if (!seenBookingIds.containsKey(bookingId)) {
                                val newBooking = mutableMapOf<String, Any>()
                                newBooking["bookingId"] = bookingId
                                newBooking["bookingDate"] = result.getString("booking_date") ?: ""
                                newBooking["totalPrice"] = result.getDouble("total_price")
                                newBooking["status"] = result.getString("status")
                                newBooking["flights"] = mutableListOf<Map<String, Any>>()
                                bookings.add(newBooking)
                                seenBookingIds[bookingId] = newBooking
                            }

                            // add this flight to the booking's flight list
                            val booking = seenBookingIds[bookingId]!!

                            @Suppress("UNCHECKED_CAST")
                            val flightList = booking["flights"] as MutableList<Map<String, Any>>
                            flightList.add(getFlightInfoFromRow(result))
                        }
                        bookings
                    }
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }


    /**
    * Gets one booking for a user.
    *
    * It returns the booking details, its flights, and its passengers.
    *
    * @param bookingId the ID of the booking
    * @param userID the ID of the user
    * @return a booking map, or null if it is not found
    */
    fun getBookingById(bookingId: Int, userID: Int): Map<String, Any>? {
        // get a single booking with its flights and passengers
        val bookingSql = """
            SELECT
                b.booking_id, b.booking_date, b.total_price, b.status, b.contact_email, b.trip_type,
                f.flight_date,
                r.flight_number, r.departure_terminal, r.arrival_terminal,
                r.planned_departure, r.base_duration_minutes,
                dep.city as departure_city, arr.city as arrival_city,
                dep.name as departure_airport_name, arr.name as arrival_airport_name,
                dep.timezone as departure_timezone, arr.timezone as arrival_timezone,
                bf.flight_sequence
            FROM bookings b
            JOIN booking_flights bf ON b.booking_id = bf.booking_id
            JOIN flights f ON bf.flight_id = f.flight_id
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            WHERE b.booking_id = ? AND b.user_id = ?
            ORDER BY bf.flight_sequence
        """

        val passengerSql = "SELECT full_name, id_number, type, seat_id FROM booking_passengers WHERE booking_id = ?"

        return try {
            Database.getConnection().use { conn ->
                // get booking and flights
                val booking = mutableMapOf<String, Any>()
                conn.prepareStatement(bookingSql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.setInt(2, userID)
                    stmt.executeQuery().use { result ->
                        val flights = mutableListOf<Map<String, Any>>()
                        var found = false

                        while (result.next()) {
                            if (!found) {
                                booking["bookingId"] = result.getInt("booking_id")
                                booking["bookingDate"] = result.getString("booking_date") ?: ""
                                booking["totalPrice"] = result.getDouble("total_price")
                                booking["status"] = result.getString("status")
                                booking["contactEmail"] = result.getString("contact_email") ?: ""
                                booking["tripType"] = result.getString("trip_type") ?: "oneway"
                                found = true
                            }
                            flights.add(getFlightInfoFromRow(result))
                        }

                        if (!found) return@use null
                        booking["flights"] = flights
                    }
                }

                // get passengers
                conn.prepareStatement(passengerSql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.executeQuery().use { result ->
                        val passengers = mutableListOf<Map<String, Any>>()
                        while (result.next()) {
                            passengers.add(
                                mapOf(
                                    "fullName" to result.getString("full_name"),
                                    "idNumber" to result.getString("id_number"),
                                    "type" to result.getString("type"),
                                    "seat" to result.getString("seat_id"),
                                ),
                            )
                        }
                        booking["passengers"] = passengers
                    }
                }

                booking
            }
        } catch (e: Exception) {
            null
        }
    }

    /**
    * Cancels a booking for a user.
    *
    * @param bookingId the ID of the booking
    * @param userID the ID of the user
    * @return true if the booking was cancelled, otherwise false
    */
    fun cancelBooking(bookingId: Int, userID: Int): Boolean {
        val sql = "UPDATE bookings SET status = 'cancelled' WHERE booking_id = ? AND user_id = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.setInt(2, userID)
                    stmt.executeUpdate() > 0
                }
            }
        } catch (e: Exception) {
            false
        }
    }  

    fun getBookingCancellationNotification(bookingId: Int, userID: Int): BookingCancellationNotification? {
        val sql = """
            SELECT b.booking_id,
                b.contact_email,
                f.flight_date,
                r.flight_number,
                dep.city AS departure_city,
                arr.city AS arrival_city
            FROM bookings b
            JOIN booking_flights bf ON b.booking_id = bf.booking_id
            JOIN flights f ON bf.flight_id = f.flight_id
            JOIN routes r ON f.route_id = r.route_id
            JOIN airports dep ON r.departure_airport = dep.airport_id
            JOIN airports arr ON r.arrival_airport = arr.airport_id
            WHERE b.booking_id = ? AND b.user_id = ? AND b.status != 'cancelled'
            ORDER BY bf.flight_sequence
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.setInt(2, userID)
                    stmt.executeQuery().use { result ->
                        val flightSummaries: MutableList<String> = mutableListOf()
                        var recipientEmail: String = ""
                        while (result.next()) {
                            recipientEmail = result.getString("contact_email") ?: recipientEmail
                            flightSummaries.add(
                                "${result.getString("flight_number")} ${result.getString("departure_city")} to ${result.getString("arrival_city")} on ${result.getString("flight_date")}",
                            )
                        }
                        if (recipientEmail.isBlank() || flightSummaries.isEmpty()) return@use null
                        BookingCancellationNotification(
                            bookingId = bookingId,
                            recipientEmail = recipientEmail,
                            flightSummary = flightSummaries.joinToString("\n"),
                        )
                    }
                }
            }
        } catch (e: Exception) {
            null
        }
    }


    /**
    * Updates the passengers for a booking.
    *
    * It checks the booking belongs to the user, removes the old passengers,
    * and adds the new ones.
    *
    * @param bookingId the ID of the booking
    * @param userID the ID of the user
    * @param passengers the updated passenger list
    * @return true if the update worked, otherwise false
    */
    fun updateBookingPassengers(bookingId: Int, userID: Int, passengers: List<Map<String, String>>): Boolean {
        // make sure booking belongs to this user
        val checkSql = "SELECT count(*) FROM bookings WHERE booking_id = ? AND user_id = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(checkSql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.setInt(2, userID)
                    stmt.executeQuery().use { result ->
                        if (!result.next() || result.getInt(1) == 0) return false
                    }
                }

                // delete old passengers and re-insert with updated info
                conn.autoCommit = false

                conn.prepareStatement("DELETE FROM booking_passengers WHERE booking_id = ?").use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.executeUpdate()
                }

                val insertSql = "INSERT INTO booking_passengers(booking_id, full_name, id_number, type, seat_id) VALUES(?, ?, ?, ?, ?)"
                conn.prepareStatement(insertSql).use { stmt ->
                    for (p in passengers) {
                        stmt.setInt(1, bookingId)
                        stmt.setString(2, p["fullName"] ?: "")
                        stmt.setString(3, p["idNumber"] ?: "")
                        stmt.setString(4, p["type"] ?: "adult")
                        stmt.setString(5, p["seat"] ?: "")
                        stmt.addBatch()
                    }
                    stmt.executeBatch()
                }

                conn.commit()
                true
            }
        } catch (e: Exception) {
            false
        }
    }


    /**
    * Creates a new booking in the database.
    *
    * It saves the booking, adds the flights and passengers, and marks the
    * chosen seats as occupied.
    *
    * @param userID the ID of the user making the booking
    * @param email the contact email for the booking
    * @param flightIds the flight IDs in the booking
    * @param totalPrice the total booking price
    * @param passengers the passenger details
    * @return true if the booking was created, otherwise false
    */
    fun createBooking(
        userID: Int,
        username: String,
        flightIds: List<Int>,
        totalPrice: Double,
        passengers: List<Map<String, String>>,
        contactEmail: String,
        contactPhone: String,
        tripType: String,
    ): Boolean {
        return try {
            Database.getConnection().use { conn ->
                conn.autoCommit = false

                // insert booking
                val bookingSql =
                    """
                    INSERT INTO bookings(
                        user_id,
                        booking_date,
                        total_price,
                        status,
                        contact_email,
                        contact_phone,
                        trip_type
                    )
                    VALUES (?, datetime('now'), ?, 'confirmed', ?, ?, ?)
                    """.trimIndent()
                val bookingStmt = conn.prepareStatement(bookingSql, java.sql.Statement.RETURN_GENERATED_KEYS)
                bookingStmt.setInt(1, userID)
                bookingStmt.setDouble(2, totalPrice)
                bookingStmt.setString(3, contactEmail)
                bookingStmt.setString(4, contactPhone)
                bookingStmt.setString(5, tripType)
                bookingStmt.executeUpdate()

                val keys = bookingStmt.generatedKeys
                if (!keys.next()) {
                    conn.rollback()
                    return false
                }
                val bookingId = keys.getInt(1)

                // insert booking flights
                val flightSql = "INSERT INTO booking_flights(booking_id, flight_id, flight_sequence) VALUES(?, ?, ?)"
                val flightStmt = conn.prepareStatement(flightSql)
                for ((index, flightId) in flightIds.withIndex()) {
                    flightStmt.setInt(1, bookingId)
                    flightStmt.setInt(2, flightId)
                    flightStmt.setInt(3, index + 1)
                    flightStmt.addBatch()
                }
                flightStmt.executeBatch()

                // insert passengers
                val passengerSql = "INSERT INTO booking_passengers(booking_id, full_name, id_number, type, seat_id) VALUES(?, ?, ?, ?, ?)"
                val passengerStmt = conn.prepareStatement(passengerSql)
                for (p in passengers) {
                    passengerStmt.setInt(1, bookingId)
                    passengerStmt.setString(2, p["fullName"] ?: "")
                    passengerStmt.setString(3, p["idNumber"] ?: "")
                    passengerStmt.setString(4, p["type"] ?: "adult")
                    passengerStmt.setString(5, p["seat"] ?: "")
                    passengerStmt.addBatch()
                }
                passengerStmt.executeBatch()

                // mark seats as occupied
                val seatSql = "UPDATE seats SET is_occupied = 1 WHERE flight_id = ? AND seat_number = ?"
                val seatStmt = conn.prepareStatement(seatSql)

                for (p in passengers) {
                    // 1. Separate "12A,14C" to ["12A", "14C"]
                    val seatString = p["seat"] ?: ""
                    val individualSeats = seatString.split(",").map { it.trim() }.filter { it.isNotEmpty() }

                    // 2. Iterate flight ID, use to get seat number
                    for ((index, flightId) in flightIds.withIndex()) {
                        if (index < individualSeats.size) {
                            val seatNumber = individualSeats[index]
                            
                            seatStmt.setInt(1, flightId)
                            seatStmt.setString(2, seatNumber)
                            seatStmt.addBatch()
                        }
                    }
                }
                seatStmt.executeBatch()

                conn.commit()
                true
            }
        } catch (e: Exception) {
             e.printStackTrace()
            false
        }
    }

    fun getLoyaltyPoints(userID: Int): Int {
        val sql = 
            """
            SELECT COALESCE(SUM(total_price), 0) AS points
            FROM bookings
            WHERE user_id = ?
            AND status = 'confirmed'
            """.trimIndent()

        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, userID)
                    
                    stmt.executeQuery().use { result ->
                        if (result.next()) {
                            result.getDouble("points").toInt()
                        } else {
                            0
                        }

                    }
                }
            }

        } catch (e: Exception){
            e.printStackTrace()
            0
        }
        }  

    fun getBookingForReschedule(bookingId: Int): Map<String, Any>? {
        // Fetch all legs in sequence order
        val sql = """
            SELECT r.departure_airport, r.arrival_airport, b.total_price, b.trip_type,
                bf.flight_sequence,
                (SELECT COUNT(*) FROM booking_flights WHERE booking_id = b.booking_id) as total_legs,
                (SELECT COUNT(*) FROM booking_passengers WHERE booking_id = b.booking_id) as passenger_count
            FROM bookings b
            JOIN booking_flights bf ON b.booking_id = bf.booking_id
            JOIN flights f ON bf.flight_id = f.flight_id
            JOIN routes r ON f.route_id = r.route_id
            WHERE b.booking_id = ?
            ORDER BY bf.flight_sequence ASC
        """
        // Get cabin for a specific flight sequence using first passenger's seat
        fun queryCabin(conn: java.sql.Connection, bookingId: Int, sequence: Int): String {
            // seat_id is stored as comma-separated e.g. "6A,1A" — index matches flight_sequence
            // sequence is 1-based, so sequence=1 → index 0, sequence=2 → index 1
            val seatSql = """
                SELECT bp.seat_id, bf.flight_id
                FROM booking_passengers bp
                JOIN booking_flights bf ON bf.booking_id = bp.booking_id AND bf.flight_sequence = ?
                WHERE bp.booking_id = ?
                ORDER BY bp.passenger_id ASC
                LIMIT 1
            """
            val seatNumber = conn.prepareStatement(seatSql).use { stmt ->
                stmt.setInt(1, sequence)
                stmt.setInt(2, bookingId)
                stmt.executeQuery().use { rs ->
                    if (!rs.next()) return "economy"
                    val seatId  = rs.getString("seat_id") ?: return "economy"
                    val seats   = seatId.split(",").map { it.trim() }
                    // sequence is 1-based; index = sequence - 1
                    seats.getOrNull(sequence - 1) ?: seats.firstOrNull() ?: return "economy"
                }
            }

            val classSql = """
                SELECT s.class as seat_class
                FROM booking_flights bf
                JOIN seats s ON s.flight_id = bf.flight_id AND s.seat_number = ?
                WHERE bf.booking_id = ? AND bf.flight_sequence = ?
                LIMIT 1
            """
            return conn.prepareStatement(classSql).use { stmt ->
                stmt.setString(1, seatNumber)
                stmt.setInt(2, bookingId)
                stmt.setInt(3, sequence)
                stmt.executeQuery().use { rs ->
                    if (rs.next()) rs.getString("seat_class")?.lowercase() ?: "economy"
                    else "economy"
                }
            }
        }
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.executeQuery().use { rs ->
                        data class LegRow(val dep: String, val arr: String, val seq: Int)
                        val legs = mutableListOf<LegRow>()
                        var totalPrice = 0.0
                        var passengerCount = 0
                        var tripType = "oneway"
                        var totalLegs = 0

                        while (rs.next()) {
                            if (legs.isEmpty()) {
                                totalPrice     = rs.getDouble("total_price")
                                passengerCount = rs.getInt("passenger_count")
                                tripType       = rs.getString("trip_type") ?: "oneway"
                                totalLegs      = rs.getInt("total_legs")
                            }
                            legs.add(LegRow(
                                dep = rs.getString("departure_airport"),
                                arr = rs.getString("arrival_airport"),
                                seq = rs.getInt("flight_sequence")
                            ))
                        }

                        if (legs.isEmpty()) return@use null

                        val outboundLegs = if (tripType == "return") {
                            legs.take(totalLegs / 2)
                        } else {
                            legs
                        }

                        val origin      = outboundLegs.first().dep
                        val destination = outboundLegs.last().arr

                        // Now totalLegs and tripType are known — safe to call queryCabin
                        val outboundCabin = queryCabin(conn, bookingId, 1)
                        println("DEBUG outboundCabin=$outboundCabin totalLegs=$totalLegs tripType=$tripType")

                        val returnSeq = totalLegs / 2 + 1
                        val returnCabin = if (tripType == "return") {
                            queryCabin(conn, bookingId, returnSeq)
                        } else null

                        mapOf(
                            "origin"         to origin,
                            "destination"    to destination,
                            "oldPrice"       to totalPrice,
                            "passengerCount" to passengerCount,
                            "tripType"       to tripType,
                            "outboundCabin"  to outboundCabin,
                            "returnCabin"    to (returnCabin ?: outboundCabin)
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /**
     * Executes a reschedule: replaces old flights, updates total price,
     * releases old seats, assigns new seat numbers, and locks new seats.
     *
     * passengerSeatSelections: Map<passengerId, newSeatNumber> (e.g. 3 to "14A")
     * newFlightIds: all flight IDs for the new booking (outbound + return legs in order)
     */
    fun executeReschedule(
        bookingId: Int,
        newFlightIds: List<Int>,
        newTotalPrice: Double,
        passengerSeatSelections: Map<Int, String>  // passengerId -> seatNumber string e.g. "14A"
    ): Boolean {
        val conn = Database.getConnection()
        return try {
            conn.setAutoCommit(false)

            // 1. Release old seats: seat_id is stored as "6A,1A" (comma-separated per leg)
            //    Need to split and match each seat number against its corresponding flight
            val getOldSeats = """
                SELECT bp.seat_id, bf.flight_id, bf.flight_sequence
                FROM booking_passengers bp
                JOIN booking_flights bf ON bf.booking_id = bp.booking_id
                WHERE bp.booking_id = ?
                ORDER BY bf.flight_sequence
            """
            val releaseStmt = conn.prepareStatement(
                "UPDATE seats SET is_occupied = 0 WHERE flight_id = ? AND seat_number = ?"
            )
            conn.prepareStatement(getOldSeats).use { stmt ->
                stmt.setInt(1, bookingId)
                stmt.executeQuery().use { rs ->
                    while (rs.next()) {
                        val seatId   = rs.getString("seat_id") ?: continue
                        val flightId = rs.getInt("flight_id")
                        val seq      = rs.getInt("flight_sequence")
                        val seats    = seatId.split(",").map { it.trim() }
                        val seatNum  = seats.getOrNull(seq - 1) ?: seats.firstOrNull() ?: continue
                        releaseStmt.setInt(1, flightId)
                        releaseStmt.setString(2, seatNum)
                        releaseStmt.addBatch()
                    }
                }
            }
            releaseStmt.executeBatch()

            // 2. Update total price on the booking
            conn.prepareStatement("UPDATE bookings SET total_price = ?, status = 'confirmed' WHERE booking_id = ?").use { stmt ->
                stmt.setDouble(1, newTotalPrice)
                stmt.setInt(2, bookingId)
                stmt.executeUpdate()
            }

            // 3. Replace all flights in booking_flights
            conn.prepareStatement("DELETE FROM booking_flights WHERE booking_id = ?").use { stmt ->
                stmt.setInt(1, bookingId)
                stmt.executeUpdate()
            }
            val insertFlight = "INSERT INTO booking_flights(booking_id, flight_id, flight_sequence) VALUES(?, ?, ?)"
            conn.prepareStatement(insertFlight).use { stmt ->
                for ((index, flightId) in newFlightIds.withIndex()) {
                    stmt.setInt(1, bookingId)
                    stmt.setInt(2, flightId)
                    stmt.setInt(3, index + 1)
                    stmt.addBatch()
                }
                stmt.executeBatch()
            }

            // 4. Update each passenger's seat_id (comma-separated for all legs) and lock all new seats
            // passengerSeatSelections: Map<passengerId, "3A,7A,16A,8A">
            val updatePassengerSeat = "UPDATE booking_passengers SET seat_id = ? WHERE booking_id = ? AND passenger_id = ?"
            val lockNewSeat = "UPDATE seats SET is_occupied = 1 WHERE flight_id = ? AND seat_number = ?"

            println("DEBUG lock: newFlightIds=$newFlightIds")
            passengerSeatSelections.forEach { (passengerId, seatsJoined) ->
                println("DEBUG lock: passengerId=$passengerId seatsJoined=$seatsJoined")
                // Update seat_id with full comma-separated string
                conn.prepareStatement(updatePassengerSeat).use { stmt ->
                    stmt.setString(1, seatsJoined)
                    stmt.setInt(2, bookingId)
                    stmt.setInt(3, passengerId)
                    stmt.executeUpdate()
                }
                // Lock each seat on its corresponding flight leg
                val seatList = seatsJoined.split(",").map { it.trim() }
                seatList.forEachIndexed { index, seatNumber ->
                    val flightId = newFlightIds.getOrNull(index) ?: return@forEachIndexed
                    println("DEBUG lock: flightId=$flightId seatNumber=$seatNumber index=$index")
                    val rows = conn.prepareStatement(lockNewSeat).use { stmt ->
                        stmt.setInt(1, flightId)
                        stmt.setString(2, seatNumber)
                        stmt.executeUpdate()
                    }
                    println("DEBUG lock: rows affected=$rows")
                }
            }

            conn.commit()
            true
        } catch (e: Exception) {
            conn.rollback()
            println("ExecuteReschedule Error:")
            e.printStackTrace()
            false
        } finally {
            conn.setAutoCommit(true)
            conn.close()
        }
    }

    fun getPassengerIdsByBooking(bookingId: Int): List<Int> {
        val ids = mutableListOf<Int>()
        val sql = "SELECT passenger_id FROM booking_passengers WHERE booking_id = ? ORDER BY passenger_id"
        Database.getConnection().use { conn ->
            conn.prepareStatement(sql).use { stmt ->
                stmt.setInt(1, bookingId)
                stmt.executeQuery().use { rs ->
                    while (rs.next()) { ids.add(rs.getInt("passenger_id")) }
                }
            }
        }
        return ids
    }

    /**
     * Returns all flight IDs associated with a booking.
     * Used to filter out original flights when showing reschedule options.
     */
    fun getFlightIdsForBooking(bookingId: Int): List<Int> {
        val sql = "SELECT flight_id FROM booking_flights WHERE booking_id = ? ORDER BY flight_sequence"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.executeQuery().use { rs ->
                        val ids = mutableListOf<Int>()
                        while (rs.next()) ids.add(rs.getInt("flight_id"))
                        ids
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    /**
     * Returns passenger details for a booking including passenger_id.
     * Used to pre-fill names on the reschedule seat selection page.
     */
    fun getPassengersForBooking(bookingId: Int): List<Map<String, Any>> {
        val sql = """
            SELECT passenger_id, full_name, id_number, type, seat_id
            FROM booking_passengers
            WHERE booking_id = ?
            ORDER BY passenger_id
        """
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, bookingId)
                    stmt.executeQuery().use { rs ->
                        val passengers = mutableListOf<Map<String, Any>>()
                        while (rs.next()) {
                            passengers.add(mapOf(
                                "passengerId" to rs.getInt("passenger_id"),
                                "fullName"    to (rs.getString("full_name") ?: ""),
                                "idNumber"    to (rs.getString("id_number") ?: ""),
                                "type"        to (rs.getString("type") ?: "adult"),
                                "seat"        to (rs.getString("seat_id") ?: "")
                            ))
                        }
                        passengers
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    fun updateUserEmail(userId: Int, newEmail: String): Boolean {
        val sql = "UPDATE users SET email = ? WHERE user_id = ?"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setString(1, newEmail)
                    stmt.setInt(2, userId)
                    stmt.executeUpdate() > 0
                }
            }
        } catch (e: Exception) { false }
    }

    fun insertChangeRequest(userId: Int, changeTo: String, type: String): Boolean {
        val sql = "INSERT INTO change_requests (user_id, change_to, change_type, status) VALUES (?, ?, ?, 'pending')"
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, userId)
                    stmt.setString(2, changeTo)
                    stmt.setString(3, type)
                    stmt.executeUpdate() > 0
                }
            }
        } catch (e: Exception) { 
            e.printStackTrace()
            false 
        }
    }

    fun getUserNotifications(userId: Int): List<Map<String, Any>> {
        val sql = """
            SELECT change_to, change_type, status 
            FROM change_requests 
            WHERE user_id = ? AND status != 'pending'
        """
        val notifications = mutableListOf<Map<String, Any>>()
        return try {
            Database.getConnection().use { conn ->
                conn.prepareStatement(sql).use { stmt ->
                    stmt.setInt(1, userId)
                    val rs = stmt.executeQuery()
                    while (rs.next()) {
                        notifications.add(mapOf(
                            "content" to rs.getString("change_to"),
                            "type" to rs.getString("change_type"),
                            "status" to rs.getString("status")
                        ))
                    }
                }
            }
         notifications
        } catch (e: Exception) {
            emptyList()
        }
    }
        
}